# Erdős Problem 593 arXiv package

The submission source is `main.tex`; bibliography data are in
`references.bib`. The generated `main.bbl` is included for arXiv
portability.

A full bibliography rebuild uses:

```text
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

When the bibliography is unchanged, the bundled `main.bbl` permits a fresh
PDF to be produced with two `pdflatex` passes.

The manuscript carries the fixed manuscript date 11 July 2026. arXiv records
submission and version dates separately.
